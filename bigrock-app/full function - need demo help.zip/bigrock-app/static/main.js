new Vue({
    el: '#app',
    data: {
        events: [],
        displayedEvents: [],
        participants: [],
        boatImages: {},
        leaderboard: [],
        hookedBoats: [],
        scalesBoats: [],
        galleryImages: [],
        currentImageIndex: 0,
        settings: {
            sounds: { hooked: true, released: true, boated: true },
            followed_boats: [],
            effects_volume: 0.5,
            radio_volume: 0.5,
            tournament: 'Kids',
            data_source: 'current',
            disable_sleep_mode: false
        },
        radioPlaying: false,
        hls: null,
        eventIndex: 0,
        scrollInterval: null,
        slideshowInterval: null,
        error: null,
        showLeaderboard: false,
        isSleepMode: false,
        lastBoatedTime: null,
        showVideoPopup: false,
        showVideo: false,
        videoBoat: '',
        videoETA: '',
        videoUrl: 'https://www.youtube.com/embed/live_stream?channel=UCuJ4Y3Z5Z5Z5Z5Z5Z5Z5Z5Z',
        isHookedUpMinimized: false,
        isScalesMinimized: false,
        wifiConnected: true,
        isLoading: true,
        appMounted: false
    },
computed: {
    followedBoats() {
        return this.settings.followed_boats || [];
    },
    logoSrc() {
        const t = this.settings?.tournament;
        if (!t) return '';
        if (t === 'Edisto Invitational Billfish') {
            return 'https://cdn.reeltimeapps.com/tournaments/logos/000/000/720/original/AppIconLight2025.png?1740721490';
        } else {
            return 'https://tournament.thebigrock.com/assets/big-rock-white-5c3b0bc68e3d5833fc237321d769b1f8741cd422693811aa9791ed34822bedac.png';
        }
    },
activeHookedBoats() {
  if (this.hookedBoats && this.hookedBoats.length > 0) {
    return this.hookedBoats;
  }

  // 💡 Force fallback using real participant data if available
  const fallback = [];

  for (let i = 0; i < Math.min(this.participants.length, 2); i++) {
    const p = this.participants[i];
    fallback.push({
      boat: p.boat || `Fallback Boat ${i + 1}`,
      angler: p.angler || `Demo Angler ${i + 1}`,
      image: p.image || "/static/images/placeholder.png",
      action: "hooked up",
      message: `${p.angler || `Demo Angler ${i + 1}`} hooked up.`,
      time: "Jul 18 @ 12:34 PM"
    });
  }

  // 🧪 If no participants loaded, use hardcoded boats
  if (fallback.length === 0) {
    fallback.push(
      {
        boat: "Fallback Boat 1",
        angler: "Demo Angler 1",
        image: "/static/images/boats/Placeholder1.jpg",
        action: "hooked up",
        message: "Demo Angler 1 hooked up.",
        time: "Jul 18 @ 12:34 PM"
      },
      {
        boat: "Fallback Boat 2",
        angler: "Demo Angler 2",
        image: "/static/images/boats/Placeholder2.jpg",
        action: "hooked up",
        message: "Demo Angler 2 hooked up.",
        time: "Jul 18 @ 12:35 PM"
      }
    );
  }

  return fallback;
},


activeScalesBoats() {
    return this.events.filter(e => (e.action || '').toLowerCase().includes('headed to scales'));
}

}
,
    methods: {
        formatTime(timeStr) {
            const date = new Date(timeStr);
            return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
        },
        formatETA(etaStr) {
            try {
                const [hour, minute] = etaStr.split(':');
                const date = new Date();
                date.setHours(parseInt(hour));
                date.setMinutes(parseInt(minute));
                return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
            } catch (e) {
                return etaStr || 'Unknown ETA';
            }
        },
async loadEvents() {
    if (this.isSleepMode) return;
    try {
        this.error = null;
        const response = await fetch('/events');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const newEvents = await response.json() || [];

        // Check if there are new events based on hookup_id or fallback to time + boat
        const currentIds = new Set(this.events.map(e => e.hookup_id || `${e.time}_${e.boat}`));
        const incomingIds = new Set(newEvents.map(e => e.hookup_id || `${e.time}_${e.boat}`));

        const isDifferent = newEvents.length !== this.events.length ||
            [...incomingIds].some(id => !currentIds.has(id));

        if (isDifferent) {
            this.events = newEvents;
            this.displayedEvents = [...newEvents].reverse();
        }
    } catch (err) {
        this.error = 'Error loading events: ' + err.message;
        console.error('⚠️ Error loading events:', err);
    }
}
,

        async loadParticipants() {
    try {
        this.error = null;
        const response = await fetch('/api/participants');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        this.participants = await response.json() || [];

        // ✅ Use 'boat' instead of missing 'name'
        this.boatImages = this.participants.reduce((acc, participant) => {
            acc[participant.boat] = participant.image;
            return acc;
        }, {});

        console.log('✅ Participants loaded:', this.participants.map(p => p.boat));
    } catch (e) {
        this.error = 'Failed to load participants: ' + e.message;
        console.error('Error loading participants:', e);
        this.participants = [];
        this.boatImages = typeof known_boat_images !== 'undefined' ? known_boat_images : {};
    }
},

        async loadLeaderboard() {
            try {
                this.error = null;
                const response = await fetch('/leaderboard');
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                this.leaderboard = await response.json() || [];
                console.log('Leaderboard loaded:', this.leaderboard);
            } catch (e) {
                this.error = 'Failed to load leaderboard: ' + e.message;
                console.error('Error loading leaderboard:', e);
                this.leaderboard = [];
            }
        },
   async loadHookedBoats() {
    if (this.isSleepMode) return;
    try {
        this.error = null;
        const response = await fetch('/hooked');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        this.hookedBoats = await response.json() || [];
        console.log('Hooked boats loaded:', this.hookedBoats);
    } catch (e) {
        this.error = 'Failed to load hooked boats: ' + e.message;
        console.error('Error loading hooked boats:', e);
        this.hookedBoats = [];
    }
}
,
        async loadScalesBoats() {
            if (this.isSleepMode) return;
            try {
                this.error = null;
                const response = await fetch('/scales');
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                this.scalesBoats = await response.json() || [];
                console.log('Scales boats loaded:', this.scalesBoats);
            } catch (e) {
                this.error = 'Failed to load scales boats: ' + e.message;
                console.error('Error loading scales boats:', e);
                this.scalesBoats = [];
            }
        },
        async loadGallery() {
            try {
                this.error = null;
                const response = await fetch('/gallery');
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                this.galleryImages = await response.json() || [];
                console.log('Gallery images loaded:', this.galleryImages);
                if (this.isSleepMode) {
                    this.startSlideshow();
                }
            } catch (e) {
                this.error = 'Failed to load gallery: ' + e.message;
                console.error('Error loading gallery:', e);
                this.galleryImages = [];
            }
        },
        async loadSettings() {
            try {
                this.error = null;
                const response = await fetch('/settings');
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                this.settings = { ...this.settings, ...await response.json() };
                this.checkSleepMode();
            } catch (e) {
                this.error = 'Failed to load settings: ' + e.message;
                console.error('Error loading settings:', e);
            }
        },
        async saveSettings() {
            try {
                await fetch('/settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.settings)
                });
                this.checkSleepMode();
                if (!this.isSleepMode) {
                    await Promise.all([
                        this.loadEvents(),
                        this.loadParticipants(),
                        this.loadLeaderboard(),
                        this.loadHookedBoats(),
                        this.loadScalesBoats()
                    ]);
                } else {
                    this.loadGallery();
                }
            } catch (e) {
                this.error = 'Failed to save settings: ' + e.message;
                console.error('Error saving settings:', e);
            }
        },
        async checkVideoTrigger() {
            try {
                const response = await fetch('/check-video-trigger');
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                const data = await response.json();
                if (data.trigger && !this.showVideoPopup && !this.showVideo) {
                    this.showVideoPopup = true;
                    this.videoBoat = typeof data.boat === 'string' ? data.boat : 'Unknown Boat';
                    this.videoETA = typeof data.eta === 'string' ? data.eta : 'Unknown ETA';
                    console.log('Video trigger data:', { boat: this.videoBoat, eta: this.videoETA });
                } else {
                    this.showVideoPopup = false;
                }
            } catch (e) {
                this.showVideoPopup = false;
                console.error('Error checking video trigger:', e);
            }
        },
        async checkWifiStatus() {
            try {
                const response = await fetch('/wifi-status');
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                const data = await response.json();
                this.wifiConnected = data.connected;
            } catch (e) {
                console.error('Error checking WiFi status:', e);
                this.wifiConnected = false;
            }
        },
        watchLive() {
            this.showVideoPopup = false;
            this.showVideo = true;
        },
        dismissVideoPopup() {
            this.showVideoPopup = false;
        },
        closeVideo() {
            this.showVideo = false;
        },
        toggleHookedUpMinimized() {
            this.isHookedUpMinimized = !this.isHookedUpMinimized;
        },
        toggleScalesMinimized() {
            this.isScalesMinimized = !this.isScalesMinimized;
        },
        checkSleepMode() {
            if (this.settings.disable_sleep_mode) {
                this.isSleepMode = false;
                this.stopSlideshow();
                this.loadEvents();
                this.loadParticipants();
                this.loadLeaderboard();
                this.loadHookedBoats();
                this.loadScalesBoats();
                return;
            }
            const now = new Date();
            const month = now.getMonth() + 1;
            const day = now.getDate();
            const hour = now.getHours();
            const minute = now.getMinutes();
            const isTournamentDay = (
                (this.settings.tournament === 'Big Rock' && month === 6 && day >= 5 && day <= 13) ||
                (this.settings.tournament === 'Kids' && month === 7 && day >= 8 && day <= 11) ||
                (this.settings.tournament === 'KWLA' && month === 6 && day >= 5 && day <= 6)
            );
            const isFishingHours = hour >= 9 && hour < 15;
            const isWithinWeighInWindow = this.lastBoatedTime && (now - this.lastBoatedTime) < 30 * 60 * 1000;
            this.isSleepMode = !isTournamentDay || (isTournamentDay && !isFishingHours && !isWithinWeighInWindow);
            if (this.isSleepMode) {
                this.stopHistoricalScroll();
                this.loadGallery();
            } else {
                this.stopSlideshow();
                this.loadEvents();
                this.loadParticipants();
                this.loadLeaderboard();
                this.loadHookedBoats();
                this.loadScalesBoats();
            }
        },
        startSlideshow() {
            this.stopSlideshow();
            if (this.galleryImages.length > 0) {
                this.slideshowInterval = setInterval(() => {
                    this.currentImageIndex = (this.currentImageIndex + 1) % this.galleryImages.length;
                }, 5000);
            }
        },
        stopSlideshow() {
            if (this.slideshowInterval) {
                clearInterval(this.slideshowInterval);
                this.slideshowInterval = null;
            }
        },
        getBoatImage(boatName) {
            if (this.boatImages[boatName]) {
                return this.boatImages[boatName];
            }
            if (typeof known_boat_images !== 'undefined' && known_boat_images[boatName]) {
                return known_boat_images[boatName];
            }
            return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAA6ElEQVR4nO3QwQ3AIBDAsNLJb3RWIC+EZE8QZc3Mx5n/dsBLzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCjbLZgJIjFtsAQAAAABJRU5ErkJggg==';
        },
        handleImageError(event) {
            event.target.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAA6ElEQVR4nO3QwQ3AIBDAsNLJb3RWIC+EZE8QZc3Mx5n/dsBLzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCswKzArMCjbLZgJIjFtsAQAAAABJRU5ErkJggg==';
        },
        startHistoricalScroll() {
            this.stopHistoricalScroll();
            this.displayedEvents = [];
            this.eventIndex = 0;
            this.scrollInterval = setInterval(() => {
                if (this.eventIndex < this.events.length) {
                    this.displayedEvents = [...this.displayedEvents, this.events[this.eventIndex]];
                    if (this.settings.sounds[this.events[this.eventIndex].action.toLowerCase().replace(' ', '')]) {
                        const sound = new Audio(`/static/sounds/${this.events[this.eventIndex].action.toLowerCase().replace(' ', '')}.mp3`);
                        sound.volume = this.settings.effects_volume;
                        sound.play().catch(e => console.error('Sound error:', e));
                    }
                    this.eventIndex++;
                    this.$nextTick(() => {
                        const feed = this.$refs.eventFeed;
                        if (feed) {
                            feed.scrollTop = feed.scrollHeight;
                        }
                    });
                } else {
                    this.stopHistoricalScroll();
                }
            }, 20000);
        },
        stopHistoricalScroll() {
            if (this.scrollInterval) {
                clearInterval(this.scrollInterval);
                this.scrollInterval = null;
            }
        },
        toggleRadio() {
    const player = document.getElementById('radio-player');
    const streamURL = 'https://cs.ebmcdn.net/eastbay-live-hs-1/event/mp4:bigrockradio/playlist.m3u8';

    if (this.radioPlaying) {
        if (this.hls) {
            this.hls.destroy();
            this.hls = null;
        }
        player.pause();
        player.src = '';
        this.radioPlaying = false;
    } else {
        if (Hls.isSupported()) {
            this.hls = new Hls();
            this.hls.loadSource(streamURL);
            this.hls.attachMedia(player);
            this.hls.on(Hls.Events.MANIFEST_PARSED, () => {
                player.volume = this.settings.radio_volume || 0.3;
                player.play().catch(e => console.error('Audio play error:', e));
                this.radioPlaying = true;
                localStorage.setItem('radioPlaying', 'true');
            });
        } else if (player.canPlayType('application/vnd.apple.mpegurl')) {
            player.src = streamURL;
            player.volume = this.settings.radio_volume || 0.3;
            player.play().catch(e => console.error('Audio play error:', e));
            this.radioPlaying = true;
            localStorage.setItem('radioPlaying', 'true');
        } else {
            console.error('HLS not supported in this browser');
        }
    }

    localStorage.setItem('radioPlaying', this.radioPlaying ? 'true' : 'false');
}
,
        goToSettings() {
            window.location.href = '/settings-page';
        },
        goToParticipants() {
            window.location.href = '/participants';
        },
        goToLeaderboard() {
            window.location.href = '/leaderboard';
        },
        goBack() {
            window.location.href = '/';
        }
    },
    watch: {
        settings: {
            handler() {
                this.saveSettings();
                localStorage.setItem('radioVolume', this.settings.radio_volume);
                const player = document.getElementById('radio-player');
                if (player && this.radioPlaying) {
                    player.volume = this.settings.radio_volume;
                }
            },
            deep: true
        }
    },
    mounted() {
    console.log('Vue instance mounted for:', window.location.pathname);
    this.isLoading = true;
    this.loadSettings();
    this.checkSleepMode();
    this.checkWifiStatus();

    // Resume radio if it was playing
    if (localStorage.getItem('radioPlaying') === 'true') {
        this.toggleRadio();
    }

    this.loadParticipants()
        .then(() => {
            console.log('Initial data load complete');
            return this.loadLeaderboard();
        })
        .then(() => {
            this.isLoading = false;
            this.appMounted = true;
            console.log('Leaderboard page data loaded');

            if (window.location.pathname !== '/leaderboard') {
                this.loadEvents();
                this.loadHookedBoats();
                this.loadScalesBoats();
                this.checkVideoTrigger();

                // 🔁 Auto-refresh every 30 seconds
               setInterval(() => {
    if (!this.isSleepMode) {
        this.loadEvents();
        this.loadHookedBoats();
        this.loadScalesBoats();
    }
}, 10000); // 10-second interval

            }
        })
        .catch(err => {
            this.error = 'Error in initial data load: ' + err.message;
            console.error('Error in initial data load:', err);
            this.isLoading = false;
            this.appMounted = true;
        });
},
});